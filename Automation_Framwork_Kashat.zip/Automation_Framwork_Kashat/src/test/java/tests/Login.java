package tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.OSP_LoginPage;
import testData.ExcelReader;

public class Login extends TestBase
{
	OSP_LoginPage OSP_LoginPage_Obj;

	@Test
	public void login () throws Exception
	{
		OSP_LoginPage_Obj = new OSP_LoginPage(driver);
		OSP_LoginPage_Obj.login(ExcelReader.getCellData(0, 1), "000000" );
	}

	@BeforeMethod
	public void beforeMethod() throws Exception 
	{
		startChromeDriver();
		driver.navigate().to("http://18.224.190.191:8080");
		ExcelReader.setExcelFile(System.getProperty("user.dir")+"//Login Data.xlsx", "Login Data");
	}

	@AfterMethod
	public void afterMethod()
	{

	}
}
