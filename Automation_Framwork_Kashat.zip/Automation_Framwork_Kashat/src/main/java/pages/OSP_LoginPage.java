package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class OSP_LoginPage extends PageBase
{
	public OSP_LoginPage (WebDriver driver)
	{
		super (driver);
	}
	
	@FindBy (id = "username")
	WebElement username_Txt;
	
	@FindBy (id = "password")
	WebElement password_Txt;
	
	@FindBy (id = "kc-login")
	WebElement signin;
	
	public void login (String username, String password)
	{
		wait.until(ExpectedConditions.elementToBeClickable(username_Txt));
		username_Txt.sendKeys(username);
		password_Txt.sendKeys(password);
		signin.click();
	}

}
